<?php

    $conexio = mysqli_connect("localhost", "super", "Alumne123", "gestinfGrup1B");

    /*if($conexio){
        echo 'Conectat existosament a la base de dades';
    }else{
        echo 'No se ha pogut connectar a la base de dades';
    }*/
?>